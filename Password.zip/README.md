# Password-Locker

## Author
Yvonne Wambui Muthui

## Description 
A python application that lets us mananage our information by generate, save and delete credientials such as passwords and usernames.

## SetUp
- Clone the Repo
- Install python 3.6
- Run `python3.6 run.py`

## Languages Used
Python 3.6

## Support
Contact: yvonnewambui28@gmail.com

## License
The project is under MIT license Copyright © 2022.All rigths reserved





